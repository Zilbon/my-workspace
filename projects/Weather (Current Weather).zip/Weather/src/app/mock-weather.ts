/* import { Weather } from "./myweather/weather";



export const WEATHER: Weather[] = [
   { id: 1, name: 'Trois-riviere' },
   { id: 2, name: 'Montreal' },
   { id: 3, name: 'Quebec' },
   { id: 4, name: 'Chambly' },
   { id: 5, name: 'Shawinigan' },
   { id: 6, name: 'Louiseville' },
   { id: 7, name: 'Yamachiche' },
   { id: 8, name: 'Pointe-du-lac' },
   { id: 9, name: 'Victoriaville' },
   { id: 10, name: 'Drummondville' }
]; */
