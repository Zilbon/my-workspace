export interface IWeather{
    name: string;
    url: string;
    dt:String;
    icon:number;
    description:string;
}